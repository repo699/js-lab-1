import logo from "./logo.svg";
import "./App.css";
import React from "react";
import LeftPanel from "./Components/LeftPanel";
import RightPanel from "./Components/RightPanel";

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      name: "Punith",
      role: "Full stach web dev",
      bio: "Lorem ipusum dolor set amet..............",
      skills: [
        "HTML",
        "CSS",
        "JS",
        "React",
        "NODE",
        "EXPRESS",
        "JAVA",
        "Python",
      ],
      Qualification: [
        {
          schoolName: "Excellent English High School",
          level: "10th",
          cgpa: "7.9",
        },
        {
          schoolName: "Seshadripuram Independent Pu College",
          level: "12th",
          cgpa: "6",
        },
        {
          schoolName: "Global Institute of Management Sciences",
          level: "BCA",
          cgpa: "8.05",
        },
        {
          schoolName: "RV College of Engineering",
          level: "MCA",
          cgpa: "8.19",
        },
      ],
      project: [
        {
          name: "Exceptions 2023",
          duration: "2 months",
          description: "Something really cool",
        },
        {
          name: "Portfolio",
          duration: "3 days",
          description: "About me",
        },
      ],
    };
  }
  render() {
    return (
      <div className="container">
        <LeftPanel
          role={this.state.role}
          bio={this.state.bio}
          skills={this.state.skills}
        />
        <RightPanel
          name={this.state.name}
          qualification={this.state.Qualification}
          project={this.state.project}
        />
      </div>
    );
  }
}

export default App;
