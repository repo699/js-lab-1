import React from "react";

function LeftPanel(props) {
  return (
    <div className="left-panel">
      <img src="" alt="image-user" />

      <h1>{props ? props.role : null}</h1>
      <h3>{props ? props.bio : null}</h3>
      <h3>
        {props
          ? props.skills.map((skill) => {
              return (
                <ul>
                  <li>{skill}</li>
                </ul>
              );
            })
          : null}
      </h3>
    </div>
  );
}

export default LeftPanel;
