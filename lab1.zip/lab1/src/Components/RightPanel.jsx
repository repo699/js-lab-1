import React from "react";

function RightPanel(props) {
  return (
    <div className="right-panel">
      <h1>{props ? props.name : null}</h1>

      <h2>Qualification</h2>
      <table border="1">
        <tr>
          <th>Institution</th>
          <th>Education</th>
          <th>CGPA</th>
        </tr>

        {props
          ? props.qualification.map((val) => {
              return (
                <tr>
                  <td>{val.schoolName}</td>
                  <td>{val.level}</td>
                  <td>{val.cgpa}</td>
                </tr>
              );
            })
          : null}
      </table>

      <h2>Projects</h2>
      <table border="1">
        <tr>
          <th>Name</th>
          <th>Duration</th>
          <th>Description</th>
        </tr>

        {props
          ? props.project.map((val) => {
              return (
                <tr>
                  <td>{val.name}</td>
                  <td>{val.duration}</td>
                  <td>{val.description}</td>
                </tr>
              );
            })
          : null}
      </table>
    </div>
  );
}

export default RightPanel;
